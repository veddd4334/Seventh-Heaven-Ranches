import React from "react";
import "./App.css";

export default function App() {
  return (
    <div>
      <h1>Seventh Heaven Ranches</h1>
      <p>This is a placeholder for your complete React app.</p>
    </div>
  );
}
